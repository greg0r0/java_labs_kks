package lab3_vector;

import lab3_vector.*;

class Program{
    public static void main(String[] args){
        VectorTestSuite tests = new VectorTestSuite();
        tests.Run();
    }
}