package lab3_vector;

public class Animal {
    private int Age;
    
    public int getAge() { return this.Age;};
    public Animal(int age){
        this.Age = age;
    }
}
