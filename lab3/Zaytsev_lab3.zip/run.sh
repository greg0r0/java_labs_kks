#compile classes
javac -Xlint:unchecked ./lab3_vector/*.java 
#run main
java ./main.java 
#delete classes
rm -rf ./lab3_vector/*.class